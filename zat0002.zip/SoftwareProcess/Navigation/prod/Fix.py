'''
    Created on Oct 8, 2016
        @author: Zachary Thompson
    Last Edited on Oct 12, 2016
        By: Zachary Thompson
'''

import os
from xml.etree import ElementTree
import datetime


class Fix():

    # Constructs a Fix object
    def __init__(self, logFile=None):
        '''
        Constructor
        '''
        if (logFile == None):
            self.fileName = "log.txt"
            self.sightingFile = ""
        else:
            self.fileName = logFile
            self.sightingFiles = ""
    
        if (len(self.fileName) < 1):
            raise ValueError('Fix.__init__:  Filename must be at least 1 character long')
        
        if (os.path.isfile('./' + self.fileName)):
            self.log = open(self.fileName, 'a')
        else:
            self.log = open(self.fileName, 'w')
            
    def __timeAndDate__(self, today):
        return(
            datetime.date.isoformat(today) + " " + str(today.hour) + ":"
            + str(today.minute) + ":" + str(today.second) + "-06:00 "
            )
            
    
    def setSightingFile(self, sightingFile=None):
        if(sightingFile == None):
            raise ValueError('Fix.setSightingFile:  expected a sightingFile')
        elif((sightingFile[(len(sightingFile)-4):]) != ".xml"):
            raise ValueError('Fix.setSightingFile: sightingFile must be an xml file')
        
        if (os.path.isfile('./' + sightingFile)):
            try:
                tryToOpen = open(sightingFile, 'a')
                tryToOpen.close()
            except:
                raise ValueError('Fix.setSightingFile: unable to open sightingFile')
            self.sightingFile = sightingFile
        else:
            raise ValueError('Fix.setSightingFile: unable to find sightingFile')
        self.sightingFile = sightingFile
        
        today = datetime.datetime.now()
        self.log.write("LOG: " + self.__timeAndDate__(today) + "Start of log\n")
        self.log.write("LOG: " + self.__timeAndDate__(today) + "Start of sighting file:  " + self.sightingFile + "\n")
        
#         for s in sightings:
#             today = datetime.datetime.now()
#             body = s.find('body')
#             sightingDate = s.find('date')
#             sightingTime = s.find('time')
#             observation = s.find('observation')
#             print(
#                 "LOG: " + self.__timeAndDate__(today) + body.text + "  " 
#                 + sightingDate.text + "  " + sightingTime.text + "  " + observation.text
#                 )
#         
#         today = datetime.datetime.now()
#         print("LOG: " + self.__timeAndDate__(today) + "End of sighting file:  " + self.sightingFile)
        #self.fileName.write('LOG: ', date.today())
        
        return self.sightingFile
    
    def getSightings(self):
        if(self.sightingFile == ""):
            raise ValueError('Fix.getSightings: No sightingFile has been set')
        approximateLatitude = "0d0.0"
        approximateLongitude = "0d0.0"
        
        dom = ElementTree.parse(self.sightingFile)
        sightings = dom.findall('sighting')
        years = [None] * len(sightings)
        months = [None] * len(sightings)
        days = [None] * len(sightings)
        hours = [None] * len(sightings)
        mins = [None] * len(sightings)
        seconds = [None] * len(sightings)
        i = 0
        
        
        for s in sightings:
            years[i] = s.find('date').text[0:4]
            months[i] = s.find('date').text[5:7]
            days[i] = s.find('date').text[8:]
            hours[i] = s.find('time').text[0:2]
            mins[i] = s.find('time').text[3:5]
            seconds[i] = s.find('time').text[6:] 
            i = i + 1
        
        bestYear = -1
        bestMonth = -1
        bestDay = -1
        bestHour = -1
        bestMin = -1
        bestSecond = -1
        numBests = 0
        i = 0
        orderSet = 0
        
        order = [None] * len(sightings)
        bests = [0] * len(sightings)
        
        while (orderSet < len(order)):
            while (i < len(years)):
                if (int(years[i]) > bestYear):
                    bestYear = int(years[i])
                i = i + 1
            i = 0
            while (i < len(years)):
                if (int(years[i]) == bestYear):
                    bests[i] = 1
                    numBests = numBests + 1
                i = i + 1
        
            i = 0
            if (numBests == 1):
                while(i < len(bests)):
                    if(bests[i] == 1):
                        order[orderSet] = i
                        continue
                    i = i + 1
            else:
                while (i < len(months)):
                    if(bests[i] == 1):
                        if(int(months[i]) > bestMonth):
                            bestMonth = int(months[i])
                    i = i + 1
                        
            numBests = 0
            i = 0
            while (i < len(months)):
                if (bests[i] == 1):
                    if(int(months[i]) == bestMonth):
                        numBests = numBests + 1
                    else:
                        bests[i] = 0
            
            i = 0            
            if (numBests == 1):
                while (i < len(bests)):
                    if(bests[i] == 1):
                        order[orderSet] = i
                        continue
            else:
                while (i < len(days)):
                    if(bests[i] == 1):
                        if(int(days[i]) > bestDay):
                            bestDay = int(days[i])
                    i = i + 1
                    
            numBests = 0
            i = 0
            while (i < len(days)):
                if (bests[i] == 1):
                    if(int(days[i]) == bestDay):
                        numBests = numBests + 1
                    else:
                        bests[i] = 0
                        
            i = 0            
            if (numBests == 1):
                while (i < len(bests)):
                    if(bests[i] == 1):
                        order[orderSet] = i
                        continue
            else:
                while (i < len(hours)):
                    if(bests[i] == 1):
                        if(int(hours[i]) > bestHour):
                            bestHour = int(hours[i])
                    i = i + 1
                    
            numBests = 0
            i = 0
            while (i < len(hours)):
                if (bests[i] == 1):
                    if(int(hours[i]) == bestHour):
                        numBests = numBests + 1
                    else:
                        bests[i] = 0
                        
            i = 0            
            if (numBests == 1):
                while (i < len(bests)):
                    if(bests[i] == 1):
                        order[orderSet] = i
                        continue
            else:
                while (i < len(mins)):
                    if(bests[i] == 1):
                        if(int(mins[i]) > bestMin):
                            bestMin = int(mins[i])
                    i = i + 1
                    
            numBests = 0
            i = 0
            while (i < len(mins)):
                if (bests[i] == 1):
                    if(int(mins[i]) == bestMin):
                        numBests = numBests + 1
                    else:
                        bests[i] = 0
                        
            i = 0            
            if (numBests == 1):
                while (i < len(bests)):
                    if(bests[i] == 1):
                        order[orderSet] = i
                        continue
            else:
                while (i < len(seconds)):
                    if(bests[i] == 1):
                        if(int(seconds[i]) > bestSecond):
                            bestSecond = int(seconds[i])
                    i = i + 1
                    
            numBests = 0
            i = 0
            while (i < len(seconds)):
                if (bests[i] == 1):
                    if(int(seconds[i]) == bestSecond):
                        numBests = numBests + 1
                    else:
                        bests[i] = 0
            
        
        return(approximateLatitude, approximateLongitude)